import Press from './Press'

export default Press

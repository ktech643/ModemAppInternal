import FirstScreen from './FirstScreen'

export default FirstScreen

import Hotels from './Hotels'

export default Hotels

import CompaignBrandsShowroom from './CompaignBrandsShowroom'

export default CompaignBrandsShowroom

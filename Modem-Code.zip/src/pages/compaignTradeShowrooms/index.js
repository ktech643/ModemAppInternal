import CompaignTradeShowrooms from './CompaignTradeShowrooms'

export default CompaignTradeShowrooms

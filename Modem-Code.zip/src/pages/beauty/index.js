import Beauty from './Beauty'

export default Beauty

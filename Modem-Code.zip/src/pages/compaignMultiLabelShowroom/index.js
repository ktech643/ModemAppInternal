import CompaignMultiLabelShowroom from './CompaignMultiLabelShowroom'

export default CompaignMultiLabelShowroom

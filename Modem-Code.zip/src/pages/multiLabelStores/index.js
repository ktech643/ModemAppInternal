import MultiLabelStores from './MultiLabelStores'

export default MultiLabelStores

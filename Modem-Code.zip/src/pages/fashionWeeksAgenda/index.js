import FashionWeeksAgenda from './FashionWeeksAgenda'

export default FashionWeeksAgenda

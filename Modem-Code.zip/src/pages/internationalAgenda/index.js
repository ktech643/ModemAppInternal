import InternationalAgenda from './InternationalAgenda'

export default InternationalAgenda

import Shows from './Shows'

export default Shows

import MultiLabelShowroom from './MultiLabelShowroom'

export default MultiLabelShowroom

import CitiesEvents from './CitiesEvents'

export default CitiesEvents
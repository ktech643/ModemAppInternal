import ConnectionsBrands from './ConnectionsBrands'

export default ConnectionsBrands

import Tabs from './Tabs'

export default Tabs

import PressOfficeContact from './PressOfficeContact'

export default PressOfficeContact

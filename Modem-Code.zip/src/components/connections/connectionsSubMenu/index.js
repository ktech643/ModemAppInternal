import ConnectionsSubMenu from './ConnectionsSubMenu'

export default ConnectionsSubMenu

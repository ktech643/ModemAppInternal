import BrowseBrandsListByAlphabet from './BrowseBrandsListByAlphabet'

export default BrowseBrandsListByAlphabet

import WebViewModal from './WebViewModal'

export default WebViewModal

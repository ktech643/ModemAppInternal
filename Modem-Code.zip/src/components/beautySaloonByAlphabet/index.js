import BeautySaloonByAlphabet from './BeautySaloonByAlphabet'

export default BeautySaloonByAlphabet

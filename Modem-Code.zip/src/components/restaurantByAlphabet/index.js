import RestaurantByAlphabet from './RestaurantByAlphabet'

export default RestaurantByAlphabet

import SingleBrand from './SingleBrand'

export default SingleBrand

import StoreByAplhabet from './StoreByAplhabet'

export default StoreByAplhabet

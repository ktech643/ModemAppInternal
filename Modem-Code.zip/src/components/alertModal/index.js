import AlertModal from './AlertModal'

export default AlertModal

import SingleContact from './SingleContact'

export default SingleContact

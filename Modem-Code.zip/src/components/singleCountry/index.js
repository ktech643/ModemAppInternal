import SingleCountry from './SingleCountry'

export default SingleCountry

import HotelByAlphabet from './HotelByAlphabet'

export default HotelByAlphabet

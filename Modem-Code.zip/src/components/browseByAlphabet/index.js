import BrowseByAlphabet from './BrowseByAlphabet'

export default BrowseByAlphabet

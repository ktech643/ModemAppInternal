import Post from './Post'

export default Post

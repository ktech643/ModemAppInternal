import City from './City'

export default City

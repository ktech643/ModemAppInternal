import MonthWiseFashionWeekAgenda from './MonthWiseFashionWeekAgenda'

export default MonthWiseFashionWeekAgenda

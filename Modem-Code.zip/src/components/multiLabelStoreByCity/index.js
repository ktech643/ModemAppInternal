import MultiLabelStoreByCity from './MultiLabelStoreByCity'

export default MultiLabelStoreByCity

import CompaignBrandDetail from './CompaignBrandDetail'

export default CompaignBrandDetail

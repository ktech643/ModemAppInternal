import SingleCategoryEvent from './SingleCategoryEvent'

export default SingleCategoryEvent

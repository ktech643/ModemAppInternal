import Agenda from './Agenda'

export default Agenda

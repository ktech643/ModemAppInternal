export const BASEURL = 'https://www.modemonline.com/api'
export const emailRegex = new RegExp(/\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/)
